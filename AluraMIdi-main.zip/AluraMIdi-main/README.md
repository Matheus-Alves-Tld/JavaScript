# AluraMIdi

### Colégio Estadual Polivalente

### Projeto feito por:

* Davi Emanuel Backon de Araujo N°: 08
* Gustavo Henrique Rinaldi Amador N°: 21
* Série: 2° ano B
